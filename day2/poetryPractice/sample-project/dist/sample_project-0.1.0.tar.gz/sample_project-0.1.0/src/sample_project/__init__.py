def greet(name:str):
    return f"hello from greet program,name:{name}"